function changeUser() {
    document.querySelector(".usercard h1").innerText = "John Conner";
}
function reject(request) {
    hide(request);
    decrementPendingRequests();
}
function decrementPendingRequests() {
    var element = document.querySelector("#pending-count")
    var count = parseInt(element.innerText);
    count = count - 1;
    element.innerText = count;
}
function incrementConnections() {
    var element = document.querySelector("#connections-count")
    var count = parseInt(element.innerText);
    count = count + 1;
    element.innerText = count;
}
function accept(request) {
    // remove the element from this list and add it to the 
    // social connections list. also increment the social connections
    // counter and decrement pending requests
    // hide the request
    hide(request);

    // get the connections division
    var connections = document.querySelector("#connections label");

    // build a new entry and add it to the connections division
    // with the name from the request
    var name=request.innerText;
    var newEntry = newConnection(name);
    document.querySelector("#connections").appendChild(newEntry);

    // change the counters on both boxes
    decrementPendingRequests();
    incrementConnections();
}
function newConnection(name) {
    // this was helpful:
    // https://www.tutorialspoint.com/how-to-add-a-new-element-to-html-dom-in-javascript#:~:text=Steps%20to%20follow%201%20First%2C%20create%20a%20div,along%20with%20text%2C%20to%20the%20existing%20div%20tag.
    // new div
    var newDiv = document.createElement("div");
    newDiv.setAttribute("class","itm");

    // new image
    var newImg = document.createElement("img");
    newImg.setAttribute("class","userimg");
    newImg.setAttribute("src","images/user-circle.png");
    newImg.setAttribute("alt","user circle...");

    // new label with user name
    var lbluser = document.createElement("label");
    var text = document.createTextNode(name);
    lbluser.setAttribute("class","listitem");
    lbluser.appendChild(text);

    // add the elements to the new div
    newDiv.appendChild(newImg);
    newDiv.appendChild(lbluser);
    return newDiv;
}
function hide(request) {
    request.setAttribute("style","display: none");
}